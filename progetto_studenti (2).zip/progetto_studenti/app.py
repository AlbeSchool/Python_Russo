from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector

app = Flask(__name__)
app.secret_key = 'super_secret_key'

# Connessione al DB
try:
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="studenti_db"
    )
    cursor = db.cursor()
except mysql.connector.Error as err:
    print(f"❌ Errore di connessione al DB: {err}")
    exit()

# Crea la tabella se non esiste
cursor.execute("""
CREATE TABLE IF NOT EXISTS utenti (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50),
    cognome VARCHAR(50),
    data_nascita DATE,
    telefono VARCHAR(20) UNIQUE,
    codice_fiscale VARCHAR(20) UNIQUE
)
""")
db.commit()

# Credenziali admin
ADMIN_USER = "Albvo"
ADMIN_PASS = "password.123"

# Login admin o utente
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Admin login
        if username == ADMIN_USER and password == ADMIN_PASS:
            session['admin'] = True
            return redirect(url_for('dashboard'))

        # Login utente registrato
        cursor.execute("SELECT * FROM utenti WHERE telefono = %s AND codice_fiscale = %s", (username, password))
        utente = cursor.fetchone()
        if utente:
            session['user'] = utente[0]
            return render_template('user_home.html', utente=utente)

        flash("Credenziali errate")
    return render_template('login.html')

# Logout
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# Registrazione utente
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        nome = request.form['nome']
        cognome = request.form['cognome']
        data_nascita = request.form['data_nascita']
        telefono = request.form['telefono']
        codice_fiscale = request.form['codice_fiscale']

        try:
            cursor.execute("""
                INSERT INTO utenti (nome, cognome, data_nascita, telefono, codice_fiscale)
                VALUES (%s, %s, %s, %s, %s)
            """, (nome, cognome, data_nascita, telefono, codice_fiscale))
            db.commit()
            flash("Registrazione avvenuta con successo!")
            return redirect(url_for('login'))
        except mysql.connector.IntegrityError:
            flash("Errore: telefono o codice fiscale già registrato")
    return render_template('register.html')

# Dashboard per admin
@app.route('/dashboard')
def dashboard():
    if not session.get('admin'):
        return redirect(url_for('login'))
    cursor.execute("SELECT * FROM utenti")
    utenti = cursor.fetchall()
    return render_template('dashboard.html', utenti=utenti)

# Modifica utente (solo admin)
@app.route('/edit/<int:user_id>', methods=['GET', 'POST'])
def edit_user(user_id):
    if not session.get('admin'):
        return redirect(url_for('login'))

    if request.method == 'POST':
        nome = request.form['nome']
        cognome = request.form['cognome']
        data_nascita = request.form['data_nascita']
        telefono = request.form['telefono']
        codice_fiscale = request.form['codice_fiscale']
        cursor.execute("""
            UPDATE utenti
            SET nome = %s, cognome = %s, data_nascita = %s, telefono = %s, codice_fiscale = %s
            WHERE id = %s
        """, (nome, cognome, data_nascita, telefono, codice_fiscale, user_id))
        db.commit()
        return redirect(url_for('dashboard'))

    cursor.execute("SELECT * FROM utenti WHERE id = %s", (user_id,))
    utente = cursor.fetchone()
    if utente:
        return render_template('edit_user.html', utente=utente)
    else:
        flash("Utente non trovato")
        return redirect(url_for('dashboard'))

# Elimina utente (solo admin)
@app.route('/delete/<int:user_id>')
def delete_user(user_id):
    if not session.get('admin'):
        return redirect(url_for('login'))
    cursor.execute("DELETE FROM utenti WHERE id = %s", (user_id,))
    db.commit()
    return redirect(url_for('dashboard'))

# Pagina utente dopo login
@app.route('/utente')
def utente_home():
    if not session.get('user'):
        return redirect(url_for('login'))
    cursor.execute("SELECT * FROM utenti WHERE id = %s", (session['user'],))
    utente = cursor.fetchone()
    return render_template('user_home.html', utente=utente)

# Avvia app
if __name__ == '__main__':
    app.run(debug=True)
