CREATE DATABASE IF NOT EXISTS studenti_db;
USE studenti_db;

CREATE TABLE IF NOT EXISTS utenti (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50),
    cognome VARCHAR(50),
    data_nascita DATE,
    telefono VARCHAR(20) UNIQUE,
    codice_fiscale VARCHAR(20) UNIQUE
);
